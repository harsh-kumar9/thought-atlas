"""CPU dry run of multi-layer / sustained steering (band conditions) on 2 tasks, 3 tokens."""
import sys; sys.modules["fla"] = None; sys.modules["fla.ops"] = None
import json, time, numpy as np, torch, polars as pl
from .common import DATA, load_tokenizer, load_model, decoder_layers, render_prompt
from .steer import build_steerers
spec = json.load(open(DATA / "runs/pilot2/run.json"))
dirs = np.load(DATA / "directions" / spec["directions"])
tok = load_tokenizer(); model = load_model(device="cpu"); layers = decoder_layers(model)
r = render_prompt(tok, "If $2^8=4^x$, what is the value of $x$?")
enc = tok([r, r], return_tensors="pt", padding=True, add_special_tokens=False)
for cond in spec["conditions"]:
    sts = build_steerers(cond, dirs)
    if sts and sts[0][1].mode == "swap":
        for _, st in sts: st.target = torch.as_tensor(st.mu[1]); st.device = None
    hooks = [layers[l].register_forward_hook(st) for l, st in sts]
    for _, st in sts: st.reset()
    torch.manual_seed(0); t0 = time.time()
    with torch.no_grad():
        out = model.generate(**enc, max_new_tokens=3, do_sample=True, temperature=0.6, top_p=0.95, top_k=20, pad_token_id=tok.pad_token_id)
    for h in hooks: h.remove()
    mags = [(l, float(st.alpha.abs().sum()) if st.alpha is not None else st.gamma) for l, st in sts]
    print(f"{cond['name']:28s} layers={[l for l,_ in sts]} steered_pos={sts[0][1].n_steered_positions if sts else 0} mags={mags[:3]} {time.time()-t0:.0f}s ->", repr(tok.decode(out[0, enc['input_ids'].shape[1]:])))
