"""CPU dry run of the hook/tokenization plumbing (no GPU): template, capture, steer, parse."""
import sys; sys.modules["fla"] = None; sys.modules["fla.ops"] = None  # CPU dry run: force the torch fallback kernels
import time, numpy as np, torch
from .common import load_tokenizer, load_model, decoder_layers, render_prompt, Capture, Steerer
from .activations import _batch_forward
from .phenotype import load_baseline_traces

tok = load_tokenizer()
t0 = time.time(); model = load_model(device="cpu"); print(f"loaded on cpu in {time.time()-t0:.0f}s")
layers = decoder_layers(model); print("n_layers", len(layers), "hidden", model.config.text_config.hidden_size)
tr = load_baseline_traces().head(2)
K = 8
gen_ids = [tok(t, add_special_tokens=False)["input_ids"][:K] for t in tr["full_text"].to_list()]
rendered = [render_prompt(tok, p) for p in tr["prompt"].to_list()]
print("rendered tail:", repr(rendered[0][-40:]))
positions = {"last_prompt": (-K - 1, -K), "mean4": (-K, -K + 4), "mean8": (-K, 10**9)}
t0 = time.time(); acts = _batch_forward(model, tok, rendered, gen_ids, K, positions); print("acts", acts.shape, acts.dtype, f"{time.time()-t0:.0f}s", "finite", np.isfinite(acts.astype(np.float32)).all())
# steer during a 3-token generation with a hook on layer 16
d = model.config.text_config.hidden_size
U = np.zeros((d, 1), np.float32); U[0, 0] = 1
st = Steerer(U, np.zeros(d, np.float32), "gamma", gamma=-1.0, pulse_k=2)
h = layers[16].register_forward_hook(st)
enc = tok(rendered, return_tensors="pt", padding=True, add_special_tokens=False)
torch.manual_seed(0)
t0 = time.time()
with torch.no_grad():
    out = model.generate(**enc, max_new_tokens=3, do_sample=True, temperature=0.6, top_p=0.95, top_k=20, pad_token_id=tok.pad_token_id)
h.remove()
print(f"generate 3 tokens x2 in {time.time()-t0:.0f}s; steerer calls={st.calls} steered_positions={st.n_steered_positions} (expect calls=3, positions=2*batch=4)")
print([tok.decode(o[enc['input_ids'].shape[1]:]) for o in out])
